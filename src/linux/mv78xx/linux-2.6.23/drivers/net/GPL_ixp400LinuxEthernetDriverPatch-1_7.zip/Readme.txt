#
-- Intel Copyright Notice --

@par
Copyright (c) 2004-2007  Intel Corporation. All Rights Reserved. 

@par 
This software program is licensed subject to the GNU
General Public License (GPL). Version 2, June 1991, available at
http://www.fsf.org/copyleft/gpl.html

























@par
-- End Intel Copyright Notice --
#


README for Intel(R) IXP400 Software Release
===========================================

All release notes are now provided on line at

    http://www.intel.com/design/network/products/npfamily/ixp425swr1.htm


