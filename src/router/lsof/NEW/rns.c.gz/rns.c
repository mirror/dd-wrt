#include <stdio.h>
#include <netdb.h>
#include <string.h>

#include <sys/types.h>

#include <arpa/inet.h>

#include<rpc/rpc.h>
#include<rpc/pmap_prot.h>
#include <sys/socket.h>


static void *getrpcportnam();

main()
{
	(void) getrpcportnam();
	return(0);
}

static void *
getrpcportnam()
{
	struct sockaddr_in server_addr;
	register struct hostent *hp;
	static struct pmaplist *head;
	int socket = RPC_ANYSOCK;
	struct timeval minutetimeout;
	register CLIENT *client;
	struct rpcent *rpc;
	
	memset((char *)&server_addr, 0, sizeof server_addr);
	server_addr.sin_family = AF_INET;
	if ((hp = gethostbyname("localhost")) != NULL)
	    memmove((caddr_t)&server_addr.sin_addr, hp->h_addr, hp->h_length);
	else
/* DEBUG		(void) inet_aton("0.0.0.0", &server_addr.sin_addr); */
	    server_addr.sin_addr.s_addr = inet_addr("0.0.0.0");
	minutetimeout.tv_sec = 60;
	minutetimeout.tv_usec = 0;
	server_addr.sin_port = htons(PMAPPORT);
	if (!(client = clnttcp_create(&server_addr, PMAPPROG, PMAPVERS, &socket,
				      50, 500)))
	{
	    return;
	}
	if (clnt_call(client, PMAPPROC_DUMP, xdr_void, NULL, xdr_pmaplist,
		      (caddr_t)&head, minutetimeout) != RPC_SUCCESS)
	{
	    clnt_destroy(client);
	    return;
	}
	for (; head; head = head->pml_next) {
	    if (head->pml_map.pm_prot == IPPROTO_TCP
	    ||  head->pml_map.pm_prot == IPPROTO_UDP)
	    {
	 	if ((rpc = getrpcbynumber(head->pml_map.pm_prog)))
		    printf("%d: (%d) %s\n", head->pml_map.pm_port,
			head->pml_map.pm_prot, rpc->r_name);
		else
		    printf("%d: (%d) %lu\n", head->pml_map.pm_port,
			head->pml_map.pm_prot,
			head->pml_map.pm_prog);
	    }
	}
	clnt_destroy(client);
}
